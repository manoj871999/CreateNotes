package com.example.createnotes.Activity;

import androidx.appcompat.app.AppCompatActivity;

import androidx.lifecycle.ViewModelProviders;


import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.format.DateFormat;
import android.util.Log;

import android.view.View;
import android.widget.Toast;


import com.example.createnotes.Dialog.ExampleDialog;
import com.example.createnotes.Model.Notes;

import com.example.createnotes.R;
import com.example.createnotes.ViewModel.NotesViewModel;
import com.example.createnotes.databinding.ActivityInsertDataBinding;


import java.util.Date;


public class InsertData extends AppCompatActivity implements ExampleDialog.ExampleDialogListener {
         ActivityInsertDataBinding binding;
    final static String TAG="RAM";
         String title,subtitle,notes;
         NotesViewModel notesViewModel;
         String priority="1";
         String lock3;
         String m ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityInsertDataBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Log.d("TAG", "onCreate: InsertData");
        notesViewModel= ViewModelProviders.of(this).get(NotesViewModel.class);
//        NotesViewModel notesViewModel = new ViewModelProvider(this).get(NotesViewModel.class);
        binding.greydone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    priority="1";
                    binding.yellowdone.setImageResource(0);
                    binding.greydone.setImageResource(R.drawable.unlocked);
            }
        });
        binding.yellowdone.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
                  priority = "2";
                  binding.yellowdone.setImageResource(R.drawable.lock);
                  openDialog();
                  binding.greydone.setImageResource(0);
          }
      });


        Log.d("TAG", "onCreate: Create Successfully"+ notesViewModel);
        binding.insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                title = binding.title.getText().toString();
               //subtitle = binding.subtitle.getText().toString();
                notes = binding.textnulti.getText().toString();
                if((title!=null||notes!=null) &&(!title.equals("")|| !notes.equals(""))){
                Log.d("TAG", "onClick: Click on Insert Button");
                createnotes(title,subtitle, notes,lock3);
                finish();
                }else {
                 finish();
                }
            }
        });
    }



    @Override
    protected void onPause() {
        super.onPause();
        title = binding.title.getText().toString();
       // subtitle = binding.subtitle.getText().toString();
        notes = binding.textnulti.getText().toString();
        Log.d(TAG, "onClick: Click on Insert Button" +title+subtitle+notes);
        if((title!=null||notes!=null)&&(!title.equals("")|| !notes.equals(""))){
//            createnotes(title, subtitle, notes,lock3);
            finish();
            Log.d(TAG, "onPause: Successfully");
        } else {
        finish();
        }
    }
    private void createnotes (String title, String subtitle, String notes, String lock3){
            Date date=new Date();
            CharSequence sequence= DateFormat.format("MMM d,yyy",date.getTime());
            Notes notes1 = new Notes();
             notes1.notesTitle=title;
            //just changed this line
            notes1.notesSubtitle = lock3;
            notes1.notesDate= (String) sequence;
            notes1.notes = notes;
          //  notes1.notesPassword = lock3;
            notes1.notespriority=priority;
            Log.d("TAG", "createnotes: createnotes Successfully 1");
            notesViewModel.insertNote(notes1);
        Toast.makeText(this, "" +notes1.notesPassword+" :"+ notes1.notespriority, Toast.LENGTH_SHORT).show();
    }
    public void openDialog(){
        ExampleDialog exampleDialog=new ExampleDialog();
        exampleDialog.show(getSupportFragmentManager(),"Create Dialog");
    }
    @Override
    public void applyTexts(String pass) {
        lock3=pass;

       // Toast.makeText(this, "Successfully bbb"+pass, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void applyno(String no) {
        priority=no;
        Log.d(TAG, "applyno:^^^^^^^^^^^^^^^^^^^^^^ "+priority +" "+ m);
    }

    @Override
    protected void onRestart() {
        Log.d(TAG, "onRestart: InsertData");
        super.onRestart();
    }


    @Override
    protected void onStop() {
        Log.d(TAG, "onStop: InsertData");
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        Log.d(TAG, "onDestroy: InsertData");
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        Log.d(TAG, "onResume: InsertData");
        super.onResume();
    }

    @Override
    protected void onStart() {
        Log.d(TAG, "onStart: InsertData");
        super.onStart();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Log.d(TAG, "onBackPressed: SUsdnjansdjk");
        title = binding.title.getText().toString();
        // subtitle = binding.subtitle.getText().toString();
        notes = binding.textnulti.getText().toString();
        Log.d(TAG, "onClick: Click on Insert Button" +title+subtitle+notes);
        if((title!=null||notes!=null)&&(!title.equals("")|| !notes.equals(""))){
           createnotes(title, subtitle, notes,lock3);
            finish();
            Log.d(TAG, "onPause: Successfully");
        } else {
            finish();
        }
    }
}