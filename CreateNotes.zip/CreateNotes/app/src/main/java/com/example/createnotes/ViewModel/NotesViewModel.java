package com.example.createnotes.ViewModel;
import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.example.createnotes.Model.Notes;
import com.example.createnotes.Repository.NotesRepository;
import java.util.List;
public class NotesViewModel extends AndroidViewModel {
public NotesRepository repository;
  public LiveData<List<Notes>>getAllNotes;
    public NotesViewModel(Application application) {
        super(application);
        repository = new NotesRepository(application);
        getAllNotes=repository.getallnotes;
    }
    public void insertNote(Notes notes){
        repository.insertNotes(notes);
    }
    public void updateNote(String field,String field2,int id,String date){
        repository.updateNotes(field,field2,id,date);
    }
    public void deleteNote(int id){
        repository.deleteNotes(id);
    }
}
