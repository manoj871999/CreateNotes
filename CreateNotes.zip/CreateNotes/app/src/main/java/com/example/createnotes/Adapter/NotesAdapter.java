package com.example.createnotes.Adapter;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.createnotes.Activity.UpdateData;
import com.example.createnotes.Dialog.ExampleDialog;
import com.example.createnotes.MainActivity;
import com.example.createnotes.Model.Notes;
import com.example.createnotes.R;

import java.util.ArrayList;
import java.util.List;
public class NotesAdapter extends RecyclerView.Adapter<NotesAdapter.notesViewholder> {
 MainActivity mainActivity;
 EditText dialogpassword;

List<Notes>allNotesitem;
 List<Notes>notes;
    public NotesAdapter(MainActivity mainActivity, List<Notes> notes) {
        this.mainActivity=mainActivity;
        this.notes=notes;
       allNotesitem =new ArrayList<>(notes);
    }


    public void searchNotes(List<Notes> filterredName){
     this.notes=filterredName;
     notifyDataSetChanged();
    }

    @NonNull
    @Override
    public notesViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view=LayoutInflater.from(mainActivity).inflate(R.layout.item_notes,parent,false);
        return new notesViewholder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull notesViewholder holder, int position) {
        Notes note=notes.get(position);
    if (note.notespriority.equals("1")){
        holder.prioritys.setBackgroundResource(R.drawable.unlocked);
    }
    else if (note.notespriority.equals("2")){
        holder.prioritys.setBackgroundResource(R.drawable.lock);
    }//else if (note.notespriority.equals("3")){
//        holder.prioritys.setBackgroundResource(R.drawable.red);
//    }
    holder.title.setText(note.notesTitle);
    holder.subtitle.setText(note.notes);
    holder.notes.setText(note.notesDate);
    //----------------------------------
//        Toast.makeText(mainActivity, "Holdern in Adapter "+ " "+note.notesSubtitle, Toast.LENGTH_SHORT).show();
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
           //     Log.d("Manoj", note.notesSubtitle);
                if (note.notesSubtitle==null) {
                    Intent intent = new Intent(mainActivity, UpdateData.class);
//                    Toast.makeText(mainActivity, " Check null codition then move UNLOCKED Notes" +
//                            " "+note.notesPassword+" "+note.notespriority, Toast.LENGTH_SHORT).show();
                    Log.d("Ram", "onClick: OK");
                    intent.putExtra("id", note.id);
                    intent.putExtra("title", note.notesTitle);
                    intent.putExtra("subtile", note.notesSubtitle);
                    intent.putExtra("notes", note.notes);
                    intent.putExtra("priority", note.notespriority);
                    mainActivity.startActivity(intent);
                }else {
                   // Toast.makeText(mainActivity, "gfggfggh", Toast.LENGTH_SHORT).show();
                    Log.d("Manoj", note.notesSubtitle);
                    AlertDialog.Builder builder=new AlertDialog.Builder(view.getRootView().getContext());
                    View view1=LayoutInflater.from(view.getRootView().getContext()).inflate(R.layout.checkpassword,null);
                    Log.d("TAG", "onClick:second successfully ");
                    builder.setView(view1).setTitle("Please Enter Password")
                            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {

                                }
                            })
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    String pass1 =dialogpassword.getText().toString();
                                    Log.d("Manoj", note.notesSubtitle);
                                    Log.d("Manoj",pass1);


                                    if (note.notesSubtitle.equals(pass1)) {
                                        //-----------------------------------
//                                        Toast.makeText(mainActivity, "  GetPassword Move Locked Notes", Toast.LENGTH_LONG).show();
                                        Intent intent = new Intent(mainActivity, UpdateData.class);
                                        Log.d("Manoj", "onClick: Paaas");
                                        intent.putExtra("id", note.id);
                                        intent.putExtra("title", note.notesTitle);
                                        intent.putExtra("notes", note.notes);
                                        intent.putExtra("subtile", note.notesSubtitle);
                                        intent.putExtra("priority", note.notespriority);
                                        mainActivity.startActivity(intent);
                                    }else {
                                        Toast.makeText(mainActivity, "Enter Currect Password", Toast.LENGTH_LONG).show();
                                    }
                                }
                            }).show();

                    dialogpassword=view1.findViewById(R.id.checkpass);

                }
            }
        });

    }
    @Override
    public int getItemCount() {
        return notes.size();
    }
    public class  notesViewholder extends RecyclerView.ViewHolder {
        TextView title,subtitle,notes;
        View prioritys;
        public notesViewholder(@NonNull View itemView) {
            super(itemView);
            title=itemView.findViewById(R.id.titles);
            subtitle=itemView.findViewById(R.id.subtitles);
            notes=itemView.findViewById(R.id.date);
            prioritys=itemView.findViewById(R.id.notespriority);
        }
    }

}
