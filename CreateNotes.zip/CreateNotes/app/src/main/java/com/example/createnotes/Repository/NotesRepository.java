package com.example.createnotes.Repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.createnotes.Dao.NotesDao;
import com.example.createnotes.Database.NotesDatabase;
import com.example.createnotes.Model.Notes;

import java.util.List;

public class NotesRepository
{

public NotesDao notesDao;

public LiveData<List<Notes>> getallnotes;
public NotesRepository(Application application){
        NotesDatabase database=NotesDatabase.getDatabaseInsetance(application);
        notesDao=database.notesDao();
        getallnotes =notesDao.getallnotes();
        }
public void insertNotes(Notes notes){
        notesDao.insertNotes(notes);

        }
public void deleteNotes(int id){
        notesDao.deleteNotes(id);

        }
public void updateNotes(String field,String field1,int id,String date){
        //notesDao.updateNotes(field,field1,id);
notesDao.updateNotes(field,field1,id,date);
        }

        }