package com.example.createnotes.Dao;

import androidx.lifecycle.LiveData;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import com.example.createnotes.Model.Notes;
import java.util.List;
@androidx.room.Dao
public interface NotesDao {

    @Query("SELECT * FROM Notes_Database")
    LiveData<List<Notes>>getallnotes();
    @Insert
    void insertNotes(Notes notes);
    @Query("DELETE FROM Notes_Database WHERE id=:id")
    void deleteNotes(int id);
    @Query("UPDATE Notes_Database SET notes_title=:field, notes=:field1,notes_date=:date WHERE id=:id")
    //@Update
    void updateNotes(String field,String field1,int id,String date);


}
