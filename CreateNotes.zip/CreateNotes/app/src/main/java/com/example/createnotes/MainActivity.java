package com.example.createnotes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SearchView;
import com.example.createnotes.Activity.InsertData;
import com.example.createnotes.Adapter.NotesAdapter;
import com.example.createnotes.Model.Notes;
import com.example.createnotes.ViewModel.NotesViewModel;
import java.util.ArrayList;
import java.util.List;
public class MainActivity extends AppCompatActivity {
        Menu mMenuItem;
        NotesViewModel notesViewModel;
        boolean myList=true;
        List<Notes>filternotesalllist;
        NotesAdapter notesAdapter;
        final static String TAG="TAG";
        RecyclerView notesRecycler;
@Override
protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        notesViewModel= ViewModelProviders.of(this).get(NotesViewModel.class);
        notesRecycler=findViewById(R.id.notesRecycler);
        findViewById(R.id.send).setOnClickListener(view -> {
        Intent intent;
        intent = new Intent(MainActivity.this, InsertData.class);
        startActivity(intent);
        Log.d("TAG", "onClick: MainActivity");
        });
        notesViewModel.getAllNotes.observe(this,notes -> {
                //send data global variale by this method
                filternotesalllist=notes;notesRecycler.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));
        notesAdapter=new NotesAdapter(this,notes);
        notesRecycler.setAdapter(notesAdapter);
        });
        }

@Override
public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.search_notes,menu);
        mMenuItem = menu;
        MenuItem menuItem=menu.findItem(R.id.search);
        SearchView searchView= (SearchView) menuItem.getActionView();
        searchView.setQueryHint("Search notes...");
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
@Override
public boolean onQueryTextSubmit(String s) {
        return false;
        }

@Override
public boolean onQueryTextChange(String s) {
        notes_Filter(s);
        return false;
        }
        });
        return super.onCreateOptionsMenu(menu);
        }
private void notes_Filter(String s) {
        Log.d("SSS", "notes_Filter: "+s);
        ArrayList<Notes>filter_Notes=new ArrayList<>();

        for (Notes notes:this.filternotesalllist) {
        if (notes.notesTitle.contains(s)||notes.notesDate.contains(s)||notes.notes.contains(s)) {

        filter_Notes.add(notes);
     }
        }

        this.notesAdapter.searchNotes(filter_Notes);//calling from Search method from adpter class
        }
         // This session is denoted by list change function inside the tool bar
        @Override
        public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id_item=item.getItemId();
        switch (id_item){
                case  R.id.share_app:
                case R.id.rating:
                case R.id.more:
                        break;
                case R.id.list:
                        if (myList){
                                mMenuItem.getItem(0).setIcon(R.drawable.ic_baseline_view_list_24);
                                Log.d(TAG, "onOptionsItemSelected: List------------"+myList);
                                notesRecycler.setLayoutManager(new StaggeredGridLayoutManager(2, LinearLayoutManager.VERTICAL));
                                myList=false;
                        } else {
                                mMenuItem.getItem(1).setIcon(R.drawable.ic_baseline_grid_on_24);
                                notesRecycler.setLayoutManager(new LinearLayoutManager(this));
                                Log.d(TAG, "onOptionsItemSelected: Cloud =============="+myList);
                                notesRecycler.setAdapter(notesAdapter);
                                myList=true;
                        }
                        break;
                default:
                        throw new IllegalStateException("Unexpected value: " + id_item);
        }
                return super.onOptionsItemSelected(item);
        }


}

