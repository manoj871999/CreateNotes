package com.example.createnotes.Activity;


        import androidx.annotation.NonNull;
        import androidx.appcompat.app.AppCompatActivity;
        import androidx.lifecycle.ViewModelProviders;


        import android.content.Intent;
        import android.os.Bundle;
        import android.text.format.DateFormat;
        import android.util.Log;
        import android.view.LayoutInflater;
        import android.view.Menu;
        import android.view.MenuInflater;
        import android.view.MenuItem;
        import android.view.View;
        import android.widget.LinearLayout;
        import android.widget.TextView;
        import android.widget.Toast;

        import com.example.createnotes.Model.Notes;
        import com.example.createnotes.R;
        import com.example.createnotes.ViewModel.NotesViewModel;

        import com.example.createnotes.databinding.ActivityUpdateDataBinding;
        import com.google.android.material.bottomsheet.BottomSheetDialog;

        import java.util.Date;

public class UpdateData extends AppCompatActivity {
    ActivityUpdateDataBinding binding;
    public String uptitles,upsubtiles,uppriority,uptextares ;
    int sid;
    String priority;
    NotesViewModel notesViewModel1;
    final static String TAG="TAG";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUpdateDataBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        notesViewModel1= ViewModelProviders.of(this).get(NotesViewModel.class);
        uptitles=getIntent().getStringExtra("title");
        upsubtiles=getIntent().getStringExtra("subtile");
        priority= uppriority=getIntent().getStringExtra("priority");
        sid=getIntent().getIntExtra("id",0);
        uptextares=getIntent().getStringExtra("notes");
        binding.uptitle.setText(uptitles);

        //  binding.upsubtitle.setText(upsubtiles);
        binding.textarea.setText(uptextares);

        switch (uppriority) {
            case "1":

                binding.upgreydone.setImageResource(R.drawable.unlocked);
                break;
            case "2":
                binding.upyellowdone.setImageResource(R.drawable.lock);
                break;


        }

        binding.upbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    String tl=binding.uptitle.getText().toString();
                    // String stl=binding.upsubtitle.getText().toString();
                    String tar=binding.textarea.getText().toString();
                    upgrade(tl,tar );
                }catch (Exception e){
                    Toast.makeText(UpdateData.this, "1", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.d("TAG", "onPause: UpdateData");
                    String tl=binding.uptitle.getText().toString();
                    String tar=binding.textarea.getText().toString();
                    if((tl+tar!=null)&&(!tl.equals("")||(!tar.equals("")))){
                        upgrade(tl,tar );
                    }
    }
    private void upgrade(String tl, String tar) {
        try {
            Date date = new Date();
            CharSequence sequence = DateFormat.format("MMM d,yyy", date.getTime());
            Notes update = new Notes();
            update.notesTitle = tl;
            update.notes = tar;
            update.id=sid;
            update.notesDate = (String) sequence;
            notesViewModel1.updateNote(update.notesTitle,update.notes,update.id,update.notesDate);
            finish();
        }catch (Exception e){
            Toast.makeText(this, "2", Toast.LENGTH_LONG).show();
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int  id_item=item.getItemId();
        int p= Integer.parseInt(priority);


        switch (id_item){
            case R.id.delete:
                BottomSheetDialog bottomSheetDialog=new BottomSheetDialog(UpdateData.this);
                View view= LayoutInflater.from(UpdateData.this).inflate(R.layout.bottom_sheet,(LinearLayout)findViewById(R.id.bottomsheet));
                bottomSheetDialog.setContentView(view);
                TextView yes,no;
                yes=view.findViewById(R.id.yes);
                no=view.findViewById(R.id.no);
                yes.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        notesViewModel1.deleteNote(sid);
                        finish();
                    }
                });
                no.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        bottomSheetDialog.dismiss();
                    }
                });
                bottomSheetDialog.show();
                break;
            case R.id.share:
                Intent intent=new Intent(Intent.ACTION_SEND);
                intent.putExtra(Intent.EXTRA_TEXT,uptextares);
                intent.setType("text/plain");
                intent=Intent.createChooser(intent,"Share By");
                startActivity(intent);
                break;
        }
        return true;
    }



}